# GitHub Issue 修正コマンド

GitHub issueを分析して修正します。

**使用方法**: `/project:fix-github-issue [issue番号]`

**実行内容**:

1. `gh issue view $ARGUMENTS` で issue の詳細を取得
2. 問題の内容を理解
3. コードベースから関連ファイルを検索
4. 必要な変更を実装
5. テストを作成・実行して修正を検証
6. リントとtype checkingをパス
7. わかりやすいコミットメッセージを作成
8. プッシュしてPRを作成

**注意事項**:
- GitHub CLI (`gh`) が必要です
- GitHub認証が完了していることを確認してください
- issue番号を引数として渡してください

**例**:
```
/project:fix-github-issue 1234
```

これでissue #1234を自動的に修正します。
