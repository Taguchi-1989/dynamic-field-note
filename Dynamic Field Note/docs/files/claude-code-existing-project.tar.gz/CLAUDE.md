# プロジェクト概要

このプロジェクトは[プロジェクト名を記載]です。

## 技術スタック

- **言語**: [例: TypeScript, Python, etc.]
- **フレームワーク**: [例: React, Next.js, FastAPI, etc.]
- **データベース**: [例: PostgreSQL, MongoDB, etc.]
- **インフラ**: [例: Docker, AWS, etc.]

## プロジェクト構成

```
project/
├── src/           # ソースコード
├── tests/         # テストファイル
├── docs/          # ドキュメント
└── .claude/       # Claude設定
```

## 開発ワークフロー

### ビルドコマンド
```bash
npm run build
# または
yarn build
```

### テスト実行
```bash
npm test
# または
yarn test
```

### リントと整形
```bash
npm run lint
npm run format
```

### 開発サーバー起動
```bash
npm run dev
```

## コーディング規約

### 一般原則
- コードは可読性を最優先
- 適切なコメントを記述
- 関数は単一責任の原則に従う
- 変数名は意味のある名前を使用

### TypeScript固有
- 型は明示的に定義
- `any`の使用は最小限に
- インターフェースとタイプエイリアスを適切に使い分け

### コミットメッセージ
```
<type>: <subject>

<body>

<footer>
```

**Type**:
- feat: 新機能
- fix: バグ修正
- docs: ドキュメント
- style: コードスタイル
- refactor: リファクタリング
- test: テスト
- chore: その他

## 重要な注意事項

### セキュリティ
- APIキーや秘密情報はコミットしない
- 環境変数を使用して機密情報を管理
- `.env`ファイルは`.gitignore`に含める

### パフォーマンス
- 大規模なデータ処理は非同期で実行
- 不要な再レンダリングを避ける
- メモリリークに注意

## よく使うタスク

### データベースマイグレーション
```bash
npm run migrate
```

### 本番環境デプロイ
```bash
npm run deploy
```

## トラブルシューティング

### よくある問題
1. **依存関係のエラー**: `npm install`または`yarn install`を再実行
2. **ビルドエラー**: `node_modules`を削除して再インストール
3. **ポート競合**: `.env`ファイルでポート番号を変更

## リソース

- [ドキュメント](./docs)
- [APIリファレンス](./docs/api.md)
- [コントリビューションガイド](./CONTRIBUTING.md)

---

**Claude Code使用時の注意**:
- このファイルの内容を常に参照してコーディング規約を守る
- 新しい機能を追加する際は既存のパターンに従う
- 不明な点があれば、このファイルを確認するか質問する
